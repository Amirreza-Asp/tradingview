import React from "react";
import { TradingViewEmbed, widgetType } from "react-tradingview-embed";
import "react-vis/dist/style.css";

var formatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD"

  // These options are needed to round to whole numbers if that's what you want.
  //minimumFractionDigits: 0, // (this suffices for whole numbers, but will print 2500.10 as $2,500.1)
  //maximumFractionDigits: 0, // (causes 2500.99 to be printed as $2,501)
});

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
  }

  state = {
    domData: [],
    times: [],
    high: [],
    low: [],
    chartData: [],
    dominanceData: [],
    globalDominance: [],
    query: "BTC",
    leaderboard: [],
    addressData: "",
    symbol: "",
    globalDom: [],
    socialData: []
  };

  componentDidMount() {
    this.loadChartData();
  }

  loadChartData = async () => {
    const response = await fetch(
      `https://api.lunarcrush.com/v2?data=assets&key=688o9wuzvzst3uybpg6eh&symbol=${this.state.query}&data_points=90&interval=day`
    );
    const data = await response.json();
    const dominanceData = [];
    const globalDominance = [];
    const dataArray = [];
    const socialDataRaw = [];
    const bulkData = data["data"][0]["timeSeries"];

    {
     
      bulkData.map(
        (y) =>
          dataArray.push({
            x: y.time * 1000,
            y: y.market_cap
          }),
        bulkData.map(
          (y) =>
            dominanceData.push({
              x: y.time * 1000,
              y: y.market_cap_global * (y.market_dominance / 100),
              z: y.market_dominance
            }),
          bulkData.map((y) =>
            socialDataRaw.push({
              x: y.time * 1000,
              y: y.social_score,
              z: y.social_dominance
            })
          ),
          bulkData.map((y) =>
            globalDominance.push({
              x: y.time * 1000,
              y: y.market_cap_global
            })
          )
        )
      );
    }
    this.setState({
      chartData: dataArray,
      dominanceData,
      globalDominance,
      socialDataRaw
    });
    this.setState({ symbol: this.state.query });
  };

  handleInputChange = () => {
    this.setState({
      query: this.search.value
    });
  };
  render() {
    const {
      chartData,
      query,
      addressData,
      symbol,
      dominanceData,
      domData,
      socialData,
      globalDominance,
      globalDom,
      socialDataRaw
    } = this.state;

    return (
      <div>
        <div className="charty">
          {(
            <TradingViewEmbed
              widgetType={widgetType.ADVANCED_CHART}
              widgetConfig={{
                interval: "1D",
                colorTheme: "light",
                width: "100%",
                symbol: query + "USD",
                studies: [
                  "MACD@tv-basicstudies",
                  "StochasticRSI@tv-basicstudies",
                  "TripleEMA@tv-basicstudies"
                ]
              }}
            />
          )}
        </div>
      </div>
    );
  }
}


export default Dashboard;
