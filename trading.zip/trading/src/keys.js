module.exports = {
  CRYPTO_COMPARE:
    "54c69a67adfc783963d3589c5a08a40a5d619b0f22b94b1c79df9acc9129c5ff",
  GLASSNODE: "1pzEImQbuhq9Qj0LynC5b4oqQog",
};
