import "./App.css";
import Trading from "./component/trading";
import Dashboard from "./component/dashboard";

function App() {
  return (
    <div className="AppContainer">
      <Dashboard />
    </div>
  );
}

export default App;
